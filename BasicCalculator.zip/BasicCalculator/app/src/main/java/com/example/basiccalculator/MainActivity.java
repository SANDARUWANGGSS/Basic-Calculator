package com.example.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn1,btn2,btn3,btn4;
    EditText firstNumber,secondNumber;
    TextView answer;
    String num1,num2;
    Double number1,number2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.btnAdd);
        btn2=findViewById(R.id.btnSub);
        btn3=findViewById(R.id.btnMulti);
        btn4=findViewById(R.id.btnDevide);
        firstNumber=findViewById(R.id.txt1);
        secondNumber=findViewById(R.id.txt2);
        answer=findViewById(R.id.txtAnswer);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1=firstNumber.getText().toString();
                num2=secondNumber.getText().toString();

                try {
                    number1=Double.parseDouble(num1);
                    number2=Double.parseDouble(num2);
                    answer.setText("Sum ="+(number1+number2)+"");
                }catch (Exception e)
                {
                    answer.setText("Please Enter Valid Numbers");
                }

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1=firstNumber.getText().toString();
                num2=secondNumber.getText().toString();

                try {
                    number1=Double.parseDouble(num1);
                    number2=Double.parseDouble(num2);
                    answer.setText("Sub ="+(number1-number2)+"");
                }catch (Exception e)
                {
                    answer.setText("Please Enter Valid Numbers");
                }
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1=firstNumber.getText().toString();
                num2=secondNumber.getText().toString();

                try {
                    number1=Double.parseDouble(num1);
                    number2=Double.parseDouble(num2);
                    answer.setText("Multi ="+(number1*number2)+"");
                }catch (Exception e)
                {
                    answer.setText("Please Enter Valid Numbers");
                }
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1=firstNumber.getText().toString();
                num2=secondNumber.getText().toString();

                try {
                    number1=Double.parseDouble(num1);
                    number2=Double.parseDouble(num2);
                    answer.setText("Devide ="+(number1/number2)+"");
                }catch (Exception e)
                {
                    answer.setText("Please Enter Valid Numbers");
                }
            }
        });
    }
}